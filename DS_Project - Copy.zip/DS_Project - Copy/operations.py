from Tkinter import *
from PIL import Image
from PIL import ImageTk
import tkMessageBox
import serial,os,playsound
import subprocess
import sqlite3
import datetime as d
from datetime import timedelta
#from viewuser import *
import viewuser
import plot
def shiver(userid):
    if not os.path.exists("data/"+str(userid)):
         os.makedirs("data/"+str(userid))
    stamp=str(d.datetime.now()).split(".")[0].replace(":","-") 
    os.makedirs("data/"+str(userid)+"/"+stamp)
    playsound.playsound("wait.mp3")
    #PORT number -Change according to the port number of the device
    SERIAL_PORT = "COM3"
    BAUD_RATE = 9600
    TIMEOUT = 1
    err=0
    fl=0
    c=1
    nextflag=0
    #initialize serial port
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout = TIMEOUT)
    #write data to the text file inside the folder
    f=open("data/"+str(userid)+"/"+stamp+"/"+str(userid)+".txt","w")
    tmp=open("temp.txt","w")
    t1=t2=""
    #start live plotting
    os.startfile("temp.py")
    while True:
        #reading from the serial 
        line = ser.readline()
        if line:
             if line=="Mode 1\r\n":
			        pass
      #             playsound.playsound("start.mp3")
             print line
             # If the read line is S then start writing data
             if line=="S\r\n":
                playsound.playsound("start.mp3")
                t1=d.datetime.now()
                fl=1
                continue
            # if the read line E then stop the wrting process
             if line=="E\r\n":
                t2=d.datetime.now()
                fl=0
                nextflag=1
                playsound.playsound("stop.mp3")
                break
            
             if fl==1:
                 if len(line)>1:
                  f.write(str(c)+","+line)
                  tmp.write(str(c)+","+line)
				  #counter(X value)
                  c+=4
            # if the read line R then stop the entire process
             if line=="R\r\n":
                 print "reset"
                 tkMessageBox.showerror("Warning","Dragging Detected System reset.!!!")
                 ser.close()
                 break
             if fl==0:
                 fl=0
                 c=1
    # save the live plotted figure into the corresponding user folder
    plot.animate(userid,stamp,1)
def mode1(userid):
    playsound.playsound("wait.mp3")
    SERIAL_PORT = "COM3"
    BAUD_RATE = 9600
    TIMEOUT = 1
    err=0
    fl=0
    c=1
    nextflag=0
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout = TIMEOUT)
##    f=open("data/"+str(userid)+".txt","w")
    tmp=open("temp.txt","w")
    t1=t2=""
    while True:
        line = ser.readline()
        if line:
                   
             print line
             if line=="S\r\n":
                playsound.playsound("start.mp3")
                t1=d.datetime.now()
                fl=1
                continue
             if line=="E\r\n":
                t2=d.datetime.now()
                # initialize flag to 2 set the process completed and to read the count
                fl=2
                # if the process completed successfull then this flag is set 1 
                nextflag=1
                playsound.playsound("stop.mp3")
                continue
             if fl==1:
                 if len(line)>1:
##                  f.write(str(c)+","+line)
                  tmp.write(str(c)+","+line)
                  c+=4
             if line=="R\r\n":
                 print "reset"
                 tkMessageBox.showerror("Warning","Dragging Detected System reset.!!!")
                 ser.close()
                 break
             if fl==2:
                 print "count",line
                 err=int(line)
                 fl=0
                 ser.close()
                 break
             if fl==0:
                 fl=0
                 c=1
    if nextflag==1:
        #Calculating the values and save it to the database mode1
        ttime=int((t2-t1).total_seconds())
        avg=str(44/float(ttime))
        print "Error",int(err-1)
        print "Total time=",ttime
        print "Average speed=",44/float(ttime)
        accuracy=100-err
        print "Accuracy",accuracy
        cnx=sqlite3.connect('patient.db')
        cur=cnx.cursor()
        query_insert_reg=("insert into mode1(userid,errors,time,average,accuracy)values(%d,%d,%d,%s,%d)"%(userid,err-1,ttime,avg,accuracy))
        cur.execute(query_insert_reg)
        cnx.commit()
                 
def mode2(userid):
    SERIAL_PORT = "COM3"
    BAUD_RATE = 9600
    TIMEOUT = 1
    err=0
    fl=0
    c=1
    nextflag=0
    t1=t2=""
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout = TIMEOUT)
    while True:
        line = ser.readline()
        if line:
             print line
             if line=="S\r\n":
                playsound.playsound("start.mp3")
                t1=d.datetime.now()
                continue
             if line=="E\r\n":
                t2=d.datetime.now()
                fl=2
                nextflag=1
                playsound.playsound("stop.mp3")
                continue
             if line=="R\r\n":
                 print "reset"
                 ser.close()
                 break
             if fl==2:
                 print "count",line
                 err=int(line)
                 fl=0
                 ser.close()
                 break
             if fl==0:
                 fl=0
                 c=1
    if nextflag==1:
        #Calculating the values and save it to the database mode2
        ttime=int((t2-t1).total_seconds())
        avg=str(75/float(ttime))
        print "Error",int(err-1)
        print "Total time=",ttime
        print "Average speed=",75/float(ttime)
        accuracy=100-err
        print "Accuracy",accuracy
        cnx=sqlite3.connect('patient.db')
        cur=cnx.cursor()
        query_insert_reg=("insert into mode2(userid,errors,time,average,accuracy)values(%d,%d,%d,%s,%d)"%(userid,err-1,ttime,avg,accuracy))
        cur.execute(query_insert_reg)
        cnx.commit()
def tester(userid):
    if len(e2.get("1.0",END))<3:
        tkMessageBox.showinfo("Warning","Please enter a Comment")
    else:
        #insert the comments in the   database
        tkMessageBox.showinfo("Status", "User ID is %d"%(userid))
        cnx=sqlite3.connect('patient.db')
        cur=cnx.cursor()
        query_insert_reg=("update user set comment='%s' where pid=%d;"%(e2.get("1.0",END),int(userid)))
        cur.execute(query_insert_reg)
        cnx.commit()
	#from viewuser import *
        viewuser.viewuser()
def nextpage(userid):
    #Gui creation
    top = Toplevel()
    print userid
    top.title("Select any methods")
    img_home = Image.open("10.jpg")
    ph_home  = ImageTk.PhotoImage(img_home)
    lbl_home  = Label(top,image=ph_home )
    lbl_home.image = ph_home
    lbl_home.grid(row=0,columnspan=10)
    l1=Label(top,text="This mode is used to find the no \n of errors from a Straight line",fg="red")
    l2=Label(top,text="This mode is used to find the no \nof errors from a Curved line",fg="red")
    # 4 buttons for tremor detection, straight line experiment,curved line experiment and finish the process.
    # 4 functions shiver,mode1 mode2 tester are called respectively
    #btn=Button(top,text="Hand Tremor Detection",height=5,command=lambda:shiver(userid))
    btn_mode1=Button(top,text="Straight line",width=10,height=2,command=lambda:mode1(userid))
    btn_mode2=Button(top,text="Curved Line",width=10,height=2,command=lambda:mode2(userid))
    btn_mode3=Button(top,text="Finish",width=15,height=5,command=lambda:tester(userid))
    l1.place(x=10,y=135)
    l2.place(x=240,y=135)
    #btn.grid(row=0,column=7)
    btn_mode1.grid(row=0,column=1)
    btn_mode2.grid(row=0,column=4)
    btn_mode3.grid(row=0,column=9)
    l=Label(top,text="Add a comment")
    global e2
    e2=Text(top,width=30,height=3)
    l.grid(row=2,column=1)
    e2.grid(row=2,column=2,columnspan=3)
    top.mainloop()

