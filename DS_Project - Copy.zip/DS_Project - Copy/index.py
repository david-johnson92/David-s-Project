#importing necessary packages
from Tkinter import * #for gui creation
from PIL import Image #opening image
from PIL import ImageTk #opening image
from viewuser import *
import datetime
from operations import * 
import tkMessageBox,csv ##to display messagebox
def insert():
        #Here the database connection is established
        cnx=sqlite3.connect('patient.db')
        cur=cnx.cursor()
        name=ety_name.get()
        dob=ety_dob.get()
        sex=ety_sex.get()
        dobflag=0
        gflag=0
        if sex=="M":
                gflag=1
        elif sex=="F":
                gflag=2
        else:
            dobflag=0    
        try:
                datetime.datetime.strptime(dob,'%Y-%m-%d')
                dobflag=1
        except:
                dobflag=0
        print dobflag
        #getting the values from the text fields
        if name.isalpha()== False:
                tkMessageBox.showinfo("Status", "Please enter Valid Name")
        elif dob=="" or dobflag==0:
                tkMessageBox.showinfo("Status", "Please enter Valid Date")
        elif sex=="" or gflag==0:
                tkMessageBox.showinfo("Status", "Please enter Valid sex")
        else:
          try:
                            #python table creation
                            cur.execute("create table user(pid INTEGER PRIMARY KEY AUTOINCREMENT, pname TEXT,address TEXT,dob TEXT,sex TEXT,age TEXT, contact TEXT,email TEXT,username TEXT, password TEXT,comment TEXT)")
                            cur.execute("CREATE TABLE mode1(id INTEGER PRIMARY KEY AUTOINCREMENT,userid INTEGER NOT NULL,errors INTEGER NOT NULL,time INTEGER NOT NULL,average INTEGER NOT NULL,accuracy INTEGER NOT NULL)")
                            cur.execute("CREATE TABLE mode2(id INTEGER PRIMARY KEY AUTOINCREMENT,userid INTEGER NOT NULL,errors INTEGER NOT NULL,time INTEGER NOT NULL,average INTEGER NOT NULL,accuracy INTEGER NOT NULL)")
                            print("Table Created")
          except: 
                            print(" Table already exists ")
          #python database insertion
          query_insert_reg=("insert into user(pname,dob,sex) values ('%s','%s','%s')" % (name,dob,sex))
          cur.execute(query_insert_reg)
          cnx.commit()
          
          query_select_id=("select max(pid) from user")
          cur.execute(query_select_id)
          uid=cur.fetchall()
          usr=0
          for row in uid:
                            usr=int(row[0])
          tkMessageBox.showinfo("Status", "Registered Successfully")
          tkMessageBox.showinfo("Status", "User ID is %d"%(usr))
          clr()
          #selecting the id of the last registered patient(current user) and pass it to the nextpage function in the operations file
          nextpage(usr)

def clr():
    ety_name.delete(0,END)
    ety_dob.delete(0,END)
    ety_sex.delete(0,END)
    top.withdraw()
def report():
        out=open("out.csv","w")
        cnx=sqlite3.connect('patient.db')
        cur=cnx.cursor()
        query="select user.id,user.pname,user.sex,user.dob,user.comment,mode1.errors,mode1.time,mode1.average,mode1.accuracy,mode2.time,mode2.average,mode2.accuracy from user left join mode1 on user.id=mode1.userid left join mode2  on user.id=mode2.userid"
        cur.execute(query)
        result=cur.fetchall()
        print(result)
        real=[]
        for  i in result:
                real.append(list(i))   
        w=csv.writer(out)
        w.writerows([['ID','Name','SEX','DOB','Comment','Mode 1 Error','Mode 1 time Taken','Mode 1 Average Speed','Mode 1 Accuracy','Mode 2 Error','Mode 2 time Taken','Mode 2 Average Speed','Mode 2 Accuracy']])
        w.writerows(real)
def home():
        # here the gui components are defined such as labels buttons and its geometry managemanet  etc
        global top
        top = Toplevel()
        top.title("Index")
        #l1 = Label(top, text=" 22q11.2DS Neuromotor Skills Assessment")
        #l1.config(font=("Courier", 20))
        #l1.grid(row=0, columnspan=5)
        img_home = Image.open("10.jpg")
        ph_home  = ImageTk.PhotoImage(img_home)
        lbl_home  = Label(top,image=ph_home )
        lbl_home.image = ph_home
        lbl_home.grid(row=2,columnspan=5)
        #For viewing the details of already registered patients, their tremour graph  and re-assesment.Here windowview function from view file is called.
        btn_view=Button(top,text="View",width="20",command=viewuser)
        #for generate the report as a csv file.Here the report function from the view file is being called
        btn_report=Button(top,text="Generate Report",width="20",command=report)
        btn_view.grid(row=3,column=4)
        btn_report.grid(row=4,column=4)
        lbl_name = Label( top, text="Name" )
        lbl_dob = Label( top, text="DOB(YYYY-MM-DD)" )
        lbl_sex = Label( top, text="Sex(M/F)" )
        global ety_name
        global ety_dob
        global ety_sex
        ety_name = Entry(top)
        ety_dob = Entry(top)
        ety_sex = Entry(top)
        #save Button.For saving the details of the patients.Here the insert function is called for inserting the entered data to the database        
        btn_save=Button(top,text="Save",width=7,command=lambda:insert())
        #this button will clear the data in text fields
        btn_cancel=Button(top,text="Cancel",width=7,command=lambda:clr())
        lbl_name.grid(row=3,column=0)
        lbl_dob.grid(row=4,column=0)
        lbl_sex.grid(row=5,column=0)
        ety_name.grid(row=3,column=1)
        ety_dob.grid(row=4,column=1)
        ety_sex.grid(row=5,column=1)
        btn_save.grid(row=11,column=0)
        btn_cancel.grid(row=11,column=1)
        top.mainloop()
#code starts from here.The home function is called
home()
