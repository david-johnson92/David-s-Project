from Tkinter import *
import sqlite3
import tkMessageBox as ms
from PIL import Image, ImageTk
from plot import *
from operations import *
import os,datetime,glob
cnx=sqlite3.connect('patient.db')
cur=cnx.cursor()
def viewPat():
    # loading dat from database
    patientid=ety_patientid.get()
    if patientid =="":
        ms.showinfo("Error","Enter the id")
    else:
        try:
            query="select * from user left join mode1 on user.id=mode1.userid left join mode2  on user.id=mode2.userid where user.id=%d;"%(int(patientid))
            cur.execute(query)
            result=cur.fetchall()
            print result
            if len(result)>0:
              for rows in result:
                pid=rows[0]
                if str(pid) == str(patientid):
                   pidv.configure(text=str(rows[0]))
                   namev.configure(text=str(rows[1]))
                   sexv.configure(text=str(rows[2]))
                   dobv.configure(text=str(rows[3]))
                   commentv.configure(text=str(rows[4]))
                   error1v.configure(text=str(rows[7]))
                   time1v.configure(text=str(rows[8]))
                   ave1v.configure(text=str(rows[9]))
                   acc1v.configure(text=str(rows[10]))
                   error2v.configure(text=str(rows[13]))
                   time2v.configure(text=str(rows[14]))
                   ave2v.configure(text=str(rows[15]))
                   acc2v.configure(text=str(rows[16]))
            else:
                ms.showinfo("Error","No such User")
        except Exception,e:
            print "Unable to fetch!!!",e
    clr()
def clr():
    ety_patientid.delete(0,END)
def graph():
    # displaying the graph
  try:
    patientid=ety_patientid.get()
    if patientid =="":
        ms.showinfo("Error","Enter the id")
    else:
        alld=max(glob.glob(os.path.join("data\\"+patientid,'*/')),key=os.path.getmtime)
        lat=alld.split("\\")[-2]
        animate(patientid,lat,0)
  except Exception,e:
      print e
      ms.showinfo("Error","Invalid User ID")
def reass():
    #re assesment
    patientid=ety_patientid.get()
    if patientid =="":
        ms.showinfo("Error","Enter the id")
    else:
        nextpage(int(patientid))
def viewuser():
    #gui creation
        top = Toplevel()
        top.title("Login")
        top.configure(background='white')
        img_home = Image.open("0.jpeg")
        ph_home  = ImageTk.PhotoImage(img_home)
        lbl_home  = Label(top,image=ph_home )
        lbl_home.image = ph_home
        lbl_patientid = Label(top, text="Patient ID ", bg="white")
        global ety_patientid
        ety_patientid = Entry(top)
        btn_view = Button(top, text="View", width=7, command=viewPat)
        lbl_home.grid(row=0,columnspan=2)
        lbl_patientid.grid(row=1,column=0)
        ety_patientid.grid(row=1,column=1)
        btn_view.grid(row=3,column=1)
        l=Label(top,text=100*"*" )
        l.grid(row=4,columnspan=5)
        global pidv,namev,sexv,dobv,error1v,time1v,ave1v
        global acc1v,error2v,time2v,ave2v,acc2v,commentv
        pid=Label(top,text="ID",width=10)
        pidv=Label(top,text="*")
        name=Label(top,text="Patient Name",width=10)
        namev=Label(top,text="*" )
        sex=Label(top,text="Sex",width=10)
        sexv=Label(top,text="*" )
        dob=Label(top,text="Date Of Birth",width=10 )
        dobv=Label(top,text="*" )
        mode1=Label(top,text="Mode 1".center(50,"*") )
        error1=Label(top,text="Error Count",width=10)
        error1v=Label(top,text="*" )
        btn_graph = Button(top, text="View graph", width=15,command=graph)
        btn_ass = Button(top, text="Re-Assessment", width=15,command=reass)
        time1=Label(top,text="Time Taken",width=10)
        time1v=Label(top,text="*" )
        ave1=Label(top,text="Average Speed",width=10)
        ave1v=Label(top,text="*" )
        acc1=Label(top,text="Accuracy",width=10)
        acc1v=Label(top,text="*" )
        mode2=Label(top,text="Mode 2".center(50,"*"))
        error2=Label(top,text="Error Count",width=10)
        error2v=Label(top,text="*" )
        time2=Label(top,text="Time Taken",width=10)
        time2v=Label(top,text="*" )
        ave2=Label(top,text="Average Speed",width=10)
        ave2v=Label(top,text="*" )
        acc2=Label(top,text="Accuracy",width=10)
        acc2v=Label(top,text="*" )
        comment=Label(top,text="Comments",width=10)
        commentv=Label(top,text="*" )

        #griding
        pid.grid(row=5,columnspan=1)
        pidv.grid(row=5,column=1)
        name.grid(row=6,columnspan=1)
        namev.grid(row=6,column=1)
        sex.grid(row=7,columnspan=1)
        sexv.grid(row=7,column=1)
        dob.grid(row=8,columnspan=1)
        dobv.grid(row=8,column=1)
        mode1.grid(row=9,columnspan=1)
        error1.grid(row=10,columnspan=1)
        error1v.grid(row=10,column=1)
        btn_graph.grid(row=10,column=3)
        btn_ass.grid(row=11,column=3)
        time1.grid(row=11,columnspan=1)
        time1v.grid(row=11,column=1)
        ave1.grid(row=12,columnspan=1)
        ave1v.grid(row=12,column=1)
        acc1.grid(row=13,columnspan=1)
        acc1v.grid(row=13,column=1)
        mode2.grid(row=14,columnspan=1)
        error2.grid(row=15,columnspan=1)
        error2v.grid(row=15,column=1)
        time2.grid(row=16,columnspan=1)
        time2v.grid(row=16,column=1)
        ave2.grid(row=17,columnspan=1)
        ave2v.grid(row=17,column=1)
        acc2.grid(row=18,columnspan=1)
        acc2v.grid(row=18,column=1)
        comment.grid(row=19,columnspan=1)
        commentv.grid(row=19,column=1)
        top.mainloop()
