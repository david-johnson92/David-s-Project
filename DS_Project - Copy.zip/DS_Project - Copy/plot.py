import matplotlib.pyplot as plt
import matplotlib.animation as animation
import datetime
import numpy as np
from pylab import ylim, title, ylabel, xlabel
from kalman import SingleStateKalmanFilter


# Initialise the Kalman Filter

A = 1  # No process innovation
C = 1  # Measurement
B = 0  # No control input
Q = 0.005  # Process covariance
R = 1  # Measurement covariance
x = 18  # Initial estimate
P = 1  # Initial covariance
c=0
kalman_filter = SingleStateKalmanFilter(A, B, C, x, P, Q, R)
random_data = []
fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)
# plotting the graph
# Empty lists for capturing filter estimates
kalman_filter_estimates = []

def animate(i,stamp,c=0):
    #read data file.......
    pullData = open("data/"+str(i)+"/"+str(i)+".txt","r").read().replace("\r","")
    dataArray = pullData.split('\n')
    xar = []
    yar = []
    for eachLine in dataArray[2:-2]:
        if len(eachLine)>1:
            l= eachLine.split(',')
            if l[1]!=" ":
              xar.append(int(l[0]))
              yar.append(float(l[1]))
        random_data = np.hstack((xar, yar))
for data in random_data:
    
    kalman_filter.step(0, data)
    kalman_filter_estimates.append(kalman_filter.current_state())

# Plot the Data for Presentation
plt.plot(random_data, 'r*')
title("Filtering Real-Time Data")
ylabel('Tremor')
xlabel('Sample')
ylim([15, 25])

plt.plot(kalman_filter_estimates, 'k', linewidth=2.0)


    
    #ax1.clear()
    #ax1.plot(xar,yar)
if c==0:
 plt.show()
if c==1:
# save figure
 fig.savefig("data/"+str(i)+"/"+stamp+"/"+"fig.png")
