import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

def animate(i):
    pullData = open("sam.txt","r").read().replace("\r","")
    dataArray = pullData.split('\n')
    xar = []
    yar = []
    for eachLine in dataArray[2:-2]:
        if len(eachLine)>1:
            l= eachLine.split(',')
            if l[1]!=" ":
              xar.append(int(l[0]))
              yar.append(float(l[1]))
    ax1.clear()
    ax1.plot(xar,yar)
ani = animation.FuncAnimation(fig, animate, interval=100)
plt.show()


